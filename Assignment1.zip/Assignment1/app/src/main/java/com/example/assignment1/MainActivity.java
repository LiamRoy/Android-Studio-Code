package com.example.assignment1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //DECLARING VARIABLES
    private EditText username;
    private EditText password;
    private TextView attempt;
    private Button login;
    private int counter = 5;

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        //RUNNING MENU.XML OVER ACTIVITY
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        //METHOD IN MENU ITEMS TO CLOSE DOWN APP
        if (id == R.id.Close) {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setMessage("Do you want to Exit?");
            builder.setCancelable(true);
            builder.setNegativeButton("YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();

                }
            });
            builder.setPositiveButton("NO", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //RUNNING LAYOUT OF ACTIVITY_MAIN.XML
        setContentView(R.layout.activity_main);

        //ATTACHING VARIABLES TO COMPONENTS
        username = (EditText)findViewById(R.id.etName);
        password = (EditText)findViewById(R.id.etPassword);
        attempt = (TextView)findViewById(R.id.attempts);
        login = (Button)findViewById(R.id.btnLogin);

        attempt.setText("No of attempts remaining: 5");

        //METHOD OF HITTING LOG IN BUTTON
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(username.getText().toString(), password.getText().toString());
                //GOES TO VALIDATE METHOD
            }
        });
    }

    //METHOD TO VALIDATE LOGIN DETAILS
    private void validate(String name, String userPassword){
        if(password.length() >= 6 &&username.length() >= 6 /*&& password.equals("Password")&& username.equals("Admin")*/){   //GETTING ERROR WHEN TRYING TO IMPLEMENT THIS
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            intent.putExtra("value", username.getText().toString());
            //INTENT ACTION TO OPEN NEXT ACTIVITY
            startActivity(intent);
            }
        else{
            counter--;
            attempt.setText("No of attempts remaining: " + String.valueOf(counter));
            if (counter == 0){
                login.setEnabled(false);
            }
        }
    }
}