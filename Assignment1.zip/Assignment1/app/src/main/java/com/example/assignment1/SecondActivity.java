package com.example.assignment1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {
    //DECLARING VARIABLES
    ArrayList<String> list = new ArrayList<>();
    ListView list_view;
    ArrayAdapter arrayAdapter;

    int updatedList;
    String updatedListv2;
    TextView result;
    String name;

    EditText number1;
    EditText number2;
    EditText number3;
    EditText number4;
    EditText number5;
    EditText number6;
    EditText number7;
    EditText number8;
    EditText number9;
    Button Add_button;
    TextView sum;
    int ans=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //
        setContentView(R.layout.activity_second);

        number1=(EditText) findViewById(R.id.num1);
        number2=(EditText) findViewById(R.id.num2);
        number3=(EditText) findViewById(R.id.num3);
        number4=(EditText) findViewById(R.id.num4);
        number5=(EditText) findViewById(R.id.num5);
        number6=(EditText) findViewById(R.id.num6);
        number7=(EditText) findViewById(R.id.num7);
        number8=(EditText) findViewById(R.id.num8);
        number9=(EditText) findViewById(R.id.num9);
        Add_button=(Button) findViewById(R.id.button);
        sum = (TextView) findViewById(R.id.sumTotal);
        Add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double num1 = Double.parseDouble(number1.getText().toString());
                double num2 = Double.parseDouble(number2.getText().toString());
                double num3 = Double.parseDouble(number3.getText().toString());
                double num4 = Double.parseDouble(number4.getText().toString());
                double num5 = Double.parseDouble(number5.getText().toString());
                double num6 = Double.parseDouble(number6.getText().toString());
                double num7 = Double.parseDouble(number7.getText().toString());
                double num8 = Double.parseDouble(number8.getText().toString());
                double num9 = Double.parseDouble(number9.getText().toString());
                double sumPrice = num1+num2+num3+num4+num5+num6+num7+num8+num9;

                String s=String.valueOf(sumPrice);
                sum.setText(s);
            }
        });

        list_view = findViewById(R.id.list_view);

        result = findViewById(R.id.total);
        name = getIntent().getStringExtra("value");
        result.setText(name);

        arrayAdapter = new ArrayAdapter(SecondActivity.this, android.R.layout.simple_list_item_1, list);
        list_view.setAdapter(arrayAdapter);

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                PopupMenu popupMenu = new PopupMenu(SecondActivity.this, view);
                popupMenu.getMenuInflater().inflate(R.menu.pop_up_menu, popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                         switch (item.getItemId()){
                             case R.id.item_update:
                                 AlertDialog.Builder builder = new AlertDialog.Builder(SecondActivity.this);
                                 View v = LayoutInflater.from(SecondActivity.this).inflate(R.layout.item_dialog,null,false);
                                 builder.setTitle("Update Item");
                                 final  EditText editText = v.findViewById(R.id.etItem);

                                 editText.setText(list.get(position));
                                 builder.setView(v);

                                 builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                                     @Override
                                     public void onClick(DialogInterface dialog, int which) {
                                         if(!editText.getText().toString().isEmpty()){
                                             list.set(position, editText.getText().toString().trim());

                                             arrayAdapter.notifyDataSetChanged();

                                             Toast.makeText(SecondActivity.this, "Item Updated", Toast.LENGTH_SHORT).show();
                                         }
                                         else{
                                             editText.setError("Error");

                                         }
                                     }
                                 });
                                 builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                     @Override
                                     public void onClick(DialogInterface dialog, int which) {
                                         dialog.dismiss();
                                     }
                                 });
                                 builder.show();
                                 break;

                             case R.id.item_delete:
                                 Toast.makeText(SecondActivity.this, "Item Deleted", Toast.LENGTH_SHORT).show();
                                 list.remove(position);

                                 arrayAdapter.notifyDataSetChanged();

                                 break;
                         }
                         return true;
                    }
                });
                popupMenu.show();

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        //RUNNING MENU2.XML OVER ACTIVITY
        inflater.inflate(R.menu.menu2,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.add:
                _addItem();
                break;
        }

        int id = item.getItemId();

        if(id == R.id.cart){

            Intent i = new Intent(SecondActivity.this, ThirdActivity.class);
            i.putExtra("value", sum.getText().toString());
            updatedList = list_view.getAdapter().getCount();
            updatedListv2 = Integer.toString(updatedList);
            i.putExtra("value2", updatedListv2);
            startActivity(i);
            finish();
            return true;
        }

        if (id == R.id.Close) {
            AlertDialog.Builder builder = new AlertDialog.Builder(SecondActivity.this);
            builder.setMessage("Do you want to Exit?");
            builder.setCancelable(true);
            builder.setNegativeButton("YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();

                }
            });
            builder.setPositiveButton("NO", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        return true;
    }

    private void _addItem() {
        AlertDialog.Builder builder = new AlertDialog.Builder(SecondActivity.this);
        builder.setTitle("Add New Item To List");

        View v = LayoutInflater.from(SecondActivity.this).inflate(R.layout.item_dialog, null, false);

        builder.setView(v);
        EditText etItem = v.findViewById(R.id.etItem);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(!etItem.getText().toString().isEmpty()) {
                    if(list.size() < 9) {

                        list.add(etItem.getText().toString().trim());

                        arrayAdapter.notifyDataSetChanged();
                    } else {

                        etItem.setError("Error, list is full");
                    }

                }else{
                        etItem.setError("Error");

                }

            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }
}