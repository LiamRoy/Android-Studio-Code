package com.example.passwordexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText username, password;
    Button login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = (Button) findViewById(R.id.button);
        username = (EditText) findViewById(R.id.editTextTextPersonName);
        password = (EditText) findViewById(R.id.editTextTextPassword);

        login.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if (login.getText().toString().equals("Liam") &&
                        password.getText().toString().equals(("password"))) {
                    openNewActivity();}
                    else{
                        Toast.makeText(getApplicationContext(), "Wrong user and password", Toast.LENGTH_SHORT).show();
                    }
                }
            });
    }
        public void openNewActivity(){
            Intent intent = new Intent(this, newActivity.class);
            startActivity(intent);

        };

}
