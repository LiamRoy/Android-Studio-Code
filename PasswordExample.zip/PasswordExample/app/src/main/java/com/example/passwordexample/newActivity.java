package com.example.passwordexample;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class newActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newactivity_main);
    }
}
